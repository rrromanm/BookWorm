create function insert_data(a integer) returns void
    language plpgsql
as
$$
DECLARE
    i INT = 0;
BEGIN
    WHILE i < a
        LOOP
            INSERT INTO index_data(value)
            VALUES (RANDOM());
            i = i + 1;
        END LOOP;
END;
$$;

alter function insert_data(integer) owner to postgres;

