create function checkroomhotelnochange() returns trigger
    language plpgsql
as
$$
    BEGIN
        IF OLD.hotelNo != NEW.hotelNo THEN
            RAISE EXCEPTION 'Updating hotelNo of a room is not allowed';
        END IF;
        RETURN NEW;
    END;
    $$;

alter function checkroomhotelnochange() owner to postgres;

