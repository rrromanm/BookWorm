create function checkifuppercase() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.hotelname = UPPER(NEW.hotelname); -- Update the hotel name to uppercase
    RETURN NEW;
END;
$$;

alter function checkifuppercase() owner to postgres;

